package kr.gjai.hwabun.service;

import java.util.List;

import kr.gjai.hwabun.entity.MemberDTO;

public interface TestService {
	public List<MemberDTO> getList();
}
