package kr.gjai.hwabun.entity;

import lombok.Data;

@Data
public class TempBasketDTO {
	
	private int cos_seq;
	private String cos_photo1;
	private String cos_name;
	private int cos_price;
	private int cnt;
	private int price;
		
}
