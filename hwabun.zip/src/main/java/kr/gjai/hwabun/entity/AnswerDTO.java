package kr.gjai.hwabun.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class AnswerDTO {

	
	// 질문에 대한 답변 한번에 받아올 바구니~~
	private int qna1;
	private int qna2;
	private int qna3;
	private int qna4;
	private int qna5;
	private int qna6;
	private int qna7;
	private int qna8;
	private int qna9;
	private int qna10;
	private int qna11;
	private int qna12;
	private int qna13;
	private int qna14;
	private int qna15;
	private int qna16;
	private int qna17;
	private int qna18;
	private int qna19;
	private int qna20;

	
}
